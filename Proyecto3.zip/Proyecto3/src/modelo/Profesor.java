
package modelo;

/**
 *
 * @author Felipe Quiroga
 */


public class Profesor {
    private int idProfesor;
    private String rut;
    private String nombre;
    private String especialidad;

    // Constructor vacío
    public Profesor() {
    }

    // Constructor completo
    public Profesor(int idProfesor, String rut, String nombre, String especialidad) {
        this.idProfesor = idProfesor;
        this.rut = rut;
        this.nombre = nombre;
        this.especialidad = especialidad;
    }

    // Constructor sin ID (para insertar nuevos)
    public Profesor(String rut, String nombre, String especialidad) {
        this.rut = rut;
        this.nombre = nombre;
        this.especialidad = especialidad;
    }

    // Getters y Setters
    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    @Override
    public String toString() {
        return nombre; // Útil para mostrar en ComboBox
    }
}
