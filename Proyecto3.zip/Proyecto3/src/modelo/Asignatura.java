
package modelo;

/**
 *
 * @author nipar
 */

public class Asignatura {
    private int idAsignatura;
    private String nombre;
    private String codigo;
    private int idProfesor;
    
    // Atributo adicional para mostrar información del profesor
    private String nombreProfesor;

    // Constructor vacío
    public Asignatura() {
    }

    // Constructor completo
    public Asignatura(int idAsignatura, String nombre, String codigo, int idProfesor) {
        this.idAsignatura = idAsignatura;
        this.nombre = nombre;
        this.codigo = codigo;
        this.idProfesor = idProfesor;
    }

    // Constructor sin ID
    public Asignatura(String nombre, String codigo, int idProfesor) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.idProfesor = idProfesor;
    }

    // Getters y Setters
    public int getIdAsignatura() {
        return idAsignatura;
    }

    public void setIdAsignatura(int idAsignatura) {
        this.idAsignatura = idAsignatura;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }

    public String getNombreProfesor() {
        return nombreProfesor;
    }

    public void setNombreProfesor(String nombreProfesor) {
        this.nombreProfesor = nombreProfesor;
    }

    @Override
    public String toString() {
        return nombre; // Útil para mostrar en ComboBox
    }
}

