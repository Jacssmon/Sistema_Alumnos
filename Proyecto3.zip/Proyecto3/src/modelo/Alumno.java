
package modelo;

/**
 *
 * @author Felipe Quiroga
 */

public class Alumno {
    private int idAlumno;
    private String rut;
    private String nombre;
    private String email;
    private int idAsignatura;
    private double nota;
    
    // Atributos adicionales para mostrar información relacionada
    private String nombreAsignatura;
    private String nombreProfesor;

    // Constructor vacío
    public Alumno() {
    }

    // Constructor completo
    public Alumno(int idAlumno, String rut, String nombre, String email, int idAsignatura, double nota) {
        this.idAlumno = idAlumno;
        this.rut = rut;
        this.nombre = nombre;
        this.email = email;
        this.idAsignatura = idAsignatura;
        this.nota = nota;
    }

    // Constructor sin ID
    public Alumno(String rut, String nombre, String email, int idAsignatura, double nota) {
        this.rut = rut;
        this.nombre = nombre;
        this.email = email;
        this.idAsignatura = idAsignatura;
        this.nota = nota;
    }

    // Getters y Setters
    public int getIdAlumno() {
        return idAlumno;
    }

    public void setIdAlumno(int idAlumno) {
        this.idAlumno = idAlumno;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getIdAsignatura() {
        return idAsignatura;
    }

    public void setIdAsignatura(int idAsignatura) {
        this.idAsignatura = idAsignatura;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getNombreAsignatura() {
        return nombreAsignatura;
    }

    public void setNombreAsignatura(String nombreAsignatura) {
        this.nombreAsignatura = nombreAsignatura;
    }

    public String getNombreProfesor() {
        return nombreProfesor;
    }

    public void setNombreProfesor(String nombreProfesor) {
        this.nombreProfesor = nombreProfesor;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "idAlumno=" + idAlumno +
                ", rut='" + rut + '\'' +
                ", nombre='" + nombre + '\'' +
                ", email='" + email + '\'' +
                ", nota=" + nota +
                '}';
    }
}
