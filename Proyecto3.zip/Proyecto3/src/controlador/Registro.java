
package controlador;


/**
 *
 * @author Felipe Quiroga
 */
import modelo.Alumno;
import modelo.Profesor;
import modelo.Asignatura;
import bd.ConexionDB;
import java.sql.*;
import java.util.ArrayList;

public class Registro {
    
    private ConexionDB conexionDB = new ConexionDB();
    
    // ==================== MÉTODOS PARA PROFESORES ====================
    
    public ArrayList<Profesor> listarProfesores() {
        ArrayList<Profesor> lista = new ArrayList<>();
        String sql = "SELECT * FROM profesores";
        
        try (Connection conn = conexionDB.obtenerConexion();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                Profesor p = new Profesor();
                p.setIdProfesor(rs.getInt("id_profesor"));
                p.setRut(rs.getString("rut"));
                p.setNombre(rs.getString("nombre"));
                p.setEspecialidad(rs.getString("especialidad"));
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return lista;
    }
    
    
    // ==================== MÉTODOS PARA ALUMNOS ====================
    
    public boolean agregarAlumno(Alumno alumno) {
        String sql = "INSERT INTO alumnos (rut, nombre, email, id_asignatura, nota) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = conexionDB.obtenerConexion();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, alumno.getRut());
            pst.setString(2, alumno.getNombre());
            pst.setString(3, alumno.getEmail());
            pst.setInt(4, alumno.getIdAsignatura ());
            pst.setDouble(5, alumno.getNota());
            return pst.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }
    
    public ArrayList<Alumno> listarAlumnos() {
        ArrayList<Alumno> lista = new ArrayList<>();
        String sql = "SELECT a.*, asig.nombre as nombre_asignatura, p.nombre as nombre_profesor " +
                     "FROM alumnos a " +
                     "INNER JOIN asignaturas asig ON a.id_asignatura = asig.id_asignatura " +
                     "INNER JOIN profesores p ON asig.id_profesor = p.id_profesor";
        
        try (Connection conn = conexionDB.obtenerConexion();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                Alumno alumno = new Alumno();
                alumno.setIdAlumno(rs.getInt("id_alumno"));
                alumno.setRut(rs.getString("rut"));
                alumno.setNombre(rs.getString("nombre"));
                alumno.setEmail(rs.getString("email"));
                alumno.setIdAsignatura(rs.getInt("id_asignatura"));
                alumno.setNota(rs.getDouble("nota"));
                alumno.setNombreAsignatura(rs.getString("nombre_asignatura"));
                alumno.setNombreProfesor(rs.getString("nombre_profesor"));
                lista.add(alumno);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return lista;
    }
    
    public Alumno buscarAlumnoPorRut(String rut) {
    String sql = "SELECT a.*, asig.nombre as nombre_asignatura, p.nombre as nombre_profesor " +
                 "FROM alumnos a " +
                 "INNER JOIN asignaturas asig ON a.id_asignatura = asig.id_asignatura " +
                 "INNER JOIN profesores p ON asig.id_profesor = p.id_profesor " +
                 "WHERE a.rut = ?";
    Alumno alumno = null;
    
    try (Connection conn = conexionDB.obtenerConexion();
         PreparedStatement pst = conn.prepareStatement(sql)) {
        
        pst.setString(1, rut);
        ResultSet rs = pst.executeQuery();
        
        if (rs.next()) {
            alumno = new Alumno();
            alumno.setIdAlumno(rs.getInt("id_alumno"));
            alumno.setRut(rs.getString("rut"));
            alumno.setNombre(rs.getString("nombre"));
            alumno.setEmail(rs.getString("email"));
            alumno.setIdAsignatura(rs.getInt("id_asignatura"));
            alumno.setNota(rs.getDouble("nota"));
            alumno.setNombreAsignatura(rs.getString("nombre_asignatura"));
            alumno.setNombreProfesor(rs.getString("nombre_profesor"));
        }
    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
    }
    return alumno;
}
   
    
    public boolean actualizarAlumno(Alumno alumno) {
        String sql = "UPDATE alumnos SET rut=?, nombre=?, email=?, id_asignatura=?, nota=? WHERE id_alumno=?";
        try (Connection conn = conexionDB.obtenerConexion();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, alumno.getRut());
            pst.setString(2, alumno.getNombre());
            pst.setString(3, alumno.getEmail());
            pst.setInt(4, alumno.getIdAsignatura());
            pst.setDouble(5, alumno.getNota());
            pst.setInt(6, alumno.getIdAlumno());
            return pst.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }
    
    public boolean eliminarAlumnoPorRut(String rut) {
    String sql = "DELETE FROM alumnos WHERE rut = ?";
    try (Connection conn = conexionDB.obtenerConexion();
         PreparedStatement pst = conn.prepareStatement(sql)) {
        
        pst.setString(1, rut);
        return pst.executeUpdate() > 0;
        
    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
        return false;
        }
    }
    
}
    
    

      

